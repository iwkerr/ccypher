# CCYPHER README

# CCypher is used to encrypt or decrypt entered text into an output text box.